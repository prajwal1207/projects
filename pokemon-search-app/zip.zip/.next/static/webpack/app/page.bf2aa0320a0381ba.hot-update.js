"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./assets/placeholder.svg":
/*!********************************!*\
  !*** ./assets/placeholder.svg ***!
  \********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval(__webpack_require__.ts("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = ({\"src\":\"/_next/static/media/placeholder.86728401.svg\",\"height\":200,\"width\":200,\"blurWidth\":0,\"blurHeight\":0});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL2Fzc2V0cy9wbGFjZWhvbGRlci5zdmciLCJtYXBwaW5ncyI6IjtBQUFBLCtEQUFlLENBQUMsMkdBQTJHIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL2Fzc2V0cy9wbGFjZWhvbGRlci5zdmc/ZmNlZiJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvbWVkaWEvcGxhY2Vob2xkZXIuODY3Mjg0MDEuc3ZnXCIsXCJoZWlnaHRcIjoyMDAsXCJ3aWR0aFwiOjIwMCxcImJsdXJXaWR0aFwiOjAsXCJibHVySGVpZ2h0XCI6MH07Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-pages-browser)/./assets/placeholder.svg\n"));

/***/ })

});